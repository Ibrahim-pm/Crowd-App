export class PostAll {
    id: string;
    msg: string;
    userid: string;
    hash: any;
    img: string;
    vid: string;
    from: string;
    fav: string;
    keep: string;
    privacy: string;
    post_type: string;
    post_id: string;
    username: any;
    profile: any;
    fav_count: any;
    com_count: any;
    keep_count: any;
    shar_count: any;
    tipcount: any;
    secure: any;
    post_email: any;
    createdAt: any;
}
